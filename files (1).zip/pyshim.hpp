// pyshim.hpp — small stand-ins for the Python / FastAPI built-ins the routers rely on.
// Every router (auth, graph, messages, ops, reports) can include this one header.
//
// Needs: Crow (https://crowcpp.org) and nlohmann/json, C++17.
#pragma once

#include <crow.h>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <random>
#include <string>

using json = nlohmann::json;

// ---- fastapi.HTTPException -------------------------------------------------
struct HTTPException {
    int status_code;
    std::string detail;
};

// Runs a route body and turns a thrown HTTPException into FastAPI's
// {"detail": "..."} error response.
inline void set_json(crow::response& response, int code, const json& body) {
    response.code = code;
    response.body = body.dump();
    response.set_header("Content-Type", "application/json");
}

template <typename F>
crow::response handle(F&& fn) {
    try {
        return fn();
    } catch (const HTTPException& e) {
        crow::response response;
        set_json(response, e.status_code, json{{"detail", e.detail}});
        return response;
    }
}

// Pydantic body parsing: a malformed / incomplete body gives 422, like FastAPI.
template <typename T>
T parse_body(const crow::request& req) {
    try {
        return json::parse(req.body).get<T>();
    } catch (const json::exception&) {
        throw HTTPException{422, "Invalid request body."};
    }
}

// ---- Response.delete_cookie(key=..., path=...) ------------------------------
inline void delete_cookie(crow::response& response, const std::string& key, const std::string& path = "/") {
    response.add_header(
        "Set-Cookie",
        key + "=\"\"; expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Path=" + path + "; SameSite=lax");
}

// ---- str helpers ------------------------------------------------------------
// str.strip()
inline std::string strip(const std::string& s) {
    std::size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

// str.lower() (ASCII)
inline std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

// len(str): counts characters (code points), not bytes, so Hindi names and
// passwords are measured the same way Python measures them.
inline std::size_t py_len(const std::string& s) {
    std::size_t n = 0;
    for (unsigned char c : s)
        if ((c & 0xC0) != 0x80) ++n;
    return n;
}

// ---- the `secrets` module ---------------------------------------------------
namespace secrets {

// secrets.randbelow(n): uniform integer in [0, n)
inline int randbelow(int n) {
    static thread_local std::random_device rd;
    std::uniform_int_distribution<int> dist(0, n - 1);
    return dist(rd);
}

// secrets.token_urlsafe(nbytes): URL-safe base64 of random bytes, no padding
inline std::string token_urlsafe(int nbytes = 32) {
    static const char* B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    static thread_local std::random_device rd;
    std::string out;
    std::uint32_t buf = 0;
    int bits = 0;
    for (int i = 0; i < nbytes; ++i) {
        buf = (buf << 8) | (rd() & 0xFFu);
        bits += 8;
        while (bits >= 6) {
            bits -= 6;
            out.push_back(B64[(buf >> bits) & 0x3Fu]);
        }
    }
    if (bits > 0) out.push_back(B64[(buf << (6 - bits)) & 0x3Fu]);
    return out;
}

}  // namespace secrets
