// auth.hpp — port of backend/routers/auth.py
#pragma once

#include <crow.h>

// Python: router = APIRouter(prefix="/auth", tags=["auth"]), mounted by server.py under /api
// Call this once from main(), where server.py used app.include_router(...).
void register_auth_routes(crow::SimpleApp& app);
