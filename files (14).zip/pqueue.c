#include <stdlib.h>
#include "pqueue.h"

/* higher severity first; equal severity -> earlier request (lower id) first */
static int higher(const Emergency *a, const Emergency *b)
{
    if (a->severity != b->severity) return a->severity > b->severity;
    return a->id < b->id;
}

static void swap(Emergency *a, Emergency *b)
{
    Emergency t = *a; *a = *b; *b = t;
}

void pq_init(PriorityQueue *q) { q->size = 0; }

int pq_push(PriorityQueue *q, const Emergency *e)
{
    if (q->size >= PQ_CAPACITY) return 0;
    int i = q->size++;
    q->items[i] = *e;
    while (i > 0) {                               /* sift up */
        int p = (i - 1) / 2;
        if (!higher(&q->items[i], &q->items[p])) break;
        swap(&q->items[i], &q->items[p]);
        i = p;
    }
    return 1;
}

int pq_pop(PriorityQueue *q, Emergency *out)
{
    if (q->size == 0) return 0;
    *out = q->items[0];
    q->items[0] = q->items[--q->size];
    int i = 0;
    for (;;) {                                    /* sift down */
        int l = 2 * i + 1, r = l + 1, b = i;
        if (l < q->size && higher(&q->items[l], &q->items[b])) b = l;
        if (r < q->size && higher(&q->items[r], &q->items[b])) b = r;
        if (b == i) break;
        swap(&q->items[i], &q->items[b]);
        i = b;
    }
    return 1;
}

int pq_snapshot(const PriorityQueue *q, Emergency *out, int max)
{
    PriorityQueue *tmp = malloc(sizeof *tmp);
    if (!tmp) return 0;
    *tmp = *q;
    int n = 0;
    while (n < max && pq_pop(tmp, &out[n])) n++;
    free(tmp);
    return n;
}
