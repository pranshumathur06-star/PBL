/* ease.h - shared types for EASE (Emergency Assistance & Smart Response Engine) */
#ifndef EASE_H
#define EASE_H

#include <time.h>

#define MAX_MSG         128
#define MAX_NAME        32
#define MAX_NODES       16
#define MAX_RESPONDERS  16
#define PQ_CAPACITY     64
#define INF             1000000
#define CONF_THRESHOLD  0.50f   /* below this a request is treated as fake / unclear */
#define MIN_PER_KM      2       /* ETA model: ~30 km/h average city speed            */

typedef enum {
    CAT_MEDICAL = 0, CAT_FIRE, CAT_ACCIDENT, CAT_CRIME, CAT_BREAKDOWN,
    CAT_UNKNOWN, CAT_COUNT
} Category;

typedef enum {
    RT_AMBULANCE = 0, RT_FIRE_TRUCK, RT_POLICE, RT_MECHANIC, RT_COUNT
} ResponderType;

typedef enum {
    ST_QUEUED = 0, ST_DISPATCHED, ST_NO_RESPONDER, ST_REJECTED
} Status;

/* One emergency request. Filled by the intake/classifier modules,
 * completed by the response module (status, responder, route, ETA). */
typedef struct {
    int      id;
    char     message[MAX_MSG];
    int      location;            /* graph node where the emergency is   */
    Category category;
    int      genuine;             /* 1 = genuine, 0 = fake/unclear       */
    float    confidence;          /* 0.0 - 1.0 from the classifier       */
    int      severity;            /* 1 - 10, drives priority queue order */
    Status   status;
    int      responder_id;        /* -1 when none                        */
    int      distance_km;
    int      eta_min;
    int      route[MAX_NODES];    /* responder base -> emergency         */
    int      route_len;
    time_t   received;
} Emergency;

const char *category_name(Category c);
const char *responder_type_name(ResponderType t);
const char *status_name(Status s);

#endif
