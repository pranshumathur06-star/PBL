/* main.c - EASE demo driver.
 * The keyword classifier below is only a stand-in for the HTTP classifier
 * module so the dashboard and response module can be run and tested alone. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "ease.h"
#include "pqueue.h"
#include "response.h"
#include "dashboard.h"

typedef struct {
    PriorityQueue   queue;
    ResponseEngine  re;
    DashboardConfig cfg;
    int             next_id;
} App;

/* ---------- stand-in classifier ---------- */
typedef struct { Category cat; int base; const char *kw[10]; } Rule;

static const Rule RULES[] = {
    { CAT_MEDICAL,   9, {"heart","unconscious","bleeding","breathing","faint",
                         "chest","seizure","collapsed",NULL} },
    { CAT_FIRE,      8, {"fire","smoke","burning","blaze","flames","explosion",NULL} },
    { CAT_ACCIDENT,  7, {"accident","crash","collision","overturned","bike",
                         "rider","hit by",NULL} },
    { CAT_CRIME,     6, {"robbery","theft","stolen","assault","armed","knife",
                         "gun","threat",NULL} },
    { CAT_BREAKDOWN, 3, {"broke down","breakdown","flat tyre","puncture",
                         "stalled","out of fuel","engine",NULL} },
};
static const char *BOOST[] = { "trapped","child","unconscious","multiple",
                               "severe","knife","gun","bleeding","explosion", NULL };
static const char *FAKE[]  = { "prank","joke","testing","lol","just kidding", NULL };

static int count_hits(const char *text, const char *const *kw)
{
    int n = 0;
    for (int i = 0; kw[i]; i++) if (strstr(text, kw[i])) n++;
    return n;
}

static void classify_stub(const char *msg, Emergency *e)
{
    char low[MAX_MSG];
    size_t i;
    for (i = 0; msg[i] && i < sizeof low - 1; i++) low[i] = (char)tolower((unsigned char)msg[i]);
    low[i] = '\0';

    int best = -1, best_hits = 0, best_score = 0;
    for (size_t r = 0; r < sizeof RULES / sizeof RULES[0]; r++) {
        int hits = count_hits(low, RULES[r].kw);
        int score = hits * 10 + RULES[r].base;
        if (hits > 0 && score > best_score) { best = (int)r; best_hits = hits; best_score = score; }
    }

    if (best < 0) {                         /* nothing recognisable */
        e->category = CAT_UNKNOWN; e->genuine = 0; e->confidence = 0.25f; e->severity = 1;
        return;
    }
    e->category = RULES[best].cat;
    e->confidence = 0.55f + 0.12f * best_hits;
    if (e->confidence > 0.97f) e->confidence = 0.97f;
    e->severity = RULES[best].base + count_hits(low, BOOST);
    if (e->severity > 10) e->severity = 10;
    e->genuine = 1;

    if (count_hits(low, FAKE) > 0) { e->genuine = 0; e->confidence = 0.15f; }
}

/* ---------- request flow ---------- */
static void submit_request(App *a, const char *msg, int loc, int show_card)
{
    Emergency e;
    memset(&e, 0, sizeof e);
    e.id = ++a->next_id;
    snprintf(e.message, sizeof e.message, "%s", msg);
    e.location = loc;
    e.received = time(NULL);
    e.responder_id = -1;
    classify_stub(msg, &e);

    if (e.genuine && e.confidence >= CONF_THRESHOLD) {
        e.status = ST_QUEUED;
        if (!pq_push(&a->queue, &e)) printf("Queue full - request #%d dropped.\n", e.id);
    } else {                                /* fake/unclear: logged, never queued */
        response_dispatch(&a->re, &e);
        if (show_card) dashboard_show_response(&a->cfg, &a->re, &e);
    }
}

static int process_next(App *a, int show_card)
{
    Emergency e;
    if (!pq_pop(&a->queue, &e)) return 0;
    response_dispatch(&a->re, &e);
    if (show_card) dashboard_show_response(&a->cfg, &a->re, &e);
    return 1;
}

static void load_samples(App *a)
{
    static const struct { const char *msg; int loc; } S[] = {
        { "Chest pain and he is unconscious near the bus stand", 1 },
        { "Fire and heavy smoke in a shop, people trapped",      2 },
        { "Car broke down on the bypass, flat tyre",             4 },
        { "Bike accident, rider bleeding on the road",           3 },
        { "lol just testing this app, prank",                    0 },
        { "Armed robbery with a knife at the market",            0 },
        { "Another heart attack, old man fainted",              10 },
    };
    for (size_t i = 0; i < sizeof S / sizeof S[0]; i++)
        submit_request(a, S[i].msg, S[i].loc, 0);
}

/* ---------- input helpers ---------- */
static int read_line(const char *prompt, char *buf, size_t n)
{
    printf("%s", prompt); fflush(stdout);
    if (!fgets(buf, (int)n, stdin)) return 0;
    buf[strcspn(buf, "\r\n")] = '\0';
    return 1;
}

static int read_int(const char *prompt, int lo, int hi)   /* -1 on EOF/invalid */
{
    char b[32];
    if (!read_line(prompt, b, sizeof b)) return -1;
    char *end;
    long v = strtol(b, &end, 10);
    if (end == b || v < lo || v > hi) return -1;
    return (int)v;
}

static void pause_for_enter(void)
{
    char b[8];
    read_line("\nPress Enter to continue...", b, sizeof b);
}

/* ---------- modes ---------- */
static void run_demo(App *a)
{
    load_samples(a);
    printf("\n>>> 7 requests received (1 is a fake)\n");
    dashboard_render(&a->cfg, &a->queue, &a->re);

    printf(">>> Dispatching in priority order\n");
    while (process_next(a, 1)) { }

    dashboard_render(&a->cfg, &a->queue, &a->re);
}

static void run_interactive(App *a)
{
    char buf[MAX_MSG];
    for (;;) {
        dashboard_render(&a->cfg, &a->queue, &a->re);
        printf("[1] Report emergency   [2] Dispatch next   [3] Dispatch all\n"
               "[4] Release responder  [5] Load sample requests   [0] Exit\n");
        int ch = read_int("Choice: ", 0, 5);
        if (ch <= 0) break;

        if (ch == 1) {
            if (!read_line("Describe the emergency: ", buf, sizeof buf) || !buf[0]) continue;
            printf("Locations:\n");
            for (int i = 0; i < a->re.graph.n; i++)
                printf("  %2d  %s\n", i, a->re.graph.names[i]);
            int loc = read_int("Location number: ", 0, a->re.graph.n - 1);
            if (loc < 0) { printf("Invalid location.\n"); pause_for_enter(); continue; }
            submit_request(a, buf, loc, 1);
            pause_for_enter();
        } else if (ch == 2) {
            if (!process_next(a, 1)) printf("Queue is empty.\n");
            pause_for_enter();
        } else if (ch == 3) {
            if (a->queue.size == 0) printf("Queue is empty.\n");
            while (process_next(a, 1)) { }
            pause_for_enter();
        } else if (ch == 4) {
            int id = read_int("Responder id (1-8): ", 1, a->re.n_responders);
            printf(id > 0 && response_release(&a->re, id)
                   ? "Responder released.\n" : "Not found or already available.\n");
            pause_for_enter();
        } else if (ch == 5) {
            load_samples(a);
        }
    }
}

int main(int argc, char **argv)
{
    App a;
    memset(&a, 0, sizeof a);
    pq_init(&a.queue);
    response_init(&a.re);
    a.cfg.use_color = 1;
    a.cfg.clear_screen = 1;
    int demo = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--demo") == 0) demo = 1;
        else if (strcmp(argv[i], "--no-color") == 0) a.cfg.use_color = 0;
        else { printf("Usage: %s [--demo] [--no-color]\n", argv[0]); return 1; }
    }
    if (a.cfg.use_color) dashboard_enable_ansi();

    if (demo) { a.cfg.clear_screen = 0; run_demo(&a); }
    else      run_interactive(&a);

    response_free(&a.re);
    return 0;
}
