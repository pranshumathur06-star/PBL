/* pqueue.h - severity-based max-heap (stand-in for the Dispatcher's queue) */
#ifndef PQUEUE_H
#define PQUEUE_H

#include "ease.h"

typedef struct {
    Emergency items[PQ_CAPACITY];
    int       size;
} PriorityQueue;

void pq_init(PriorityQueue *q);
int  pq_push(PriorityQueue *q, const Emergency *e);   /* 1 ok, 0 full  */
int  pq_pop(PriorityQueue *q, Emergency *out);        /* 1 ok, 0 empty */
/* Non-destructive: copies up to `max` items in dispatch order. */
int  pq_snapshot(const PriorityQueue *q, Emergency *out, int max);

#endif
