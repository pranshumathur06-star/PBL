/* dashboard.h - console dashboard: live queue, classification results,
 * dispatch outcomes, responder fleet and helpline directory. */
#ifndef DASHBOARD_H
#define DASHBOARD_H

#include "ease.h"
#include "pqueue.h"
#include "response.h"

typedef struct {
    int use_color;      /* ANSI colours on/off                     */
    int clear_screen;   /* redraw in place (interactive) or append */
} DashboardConfig;

void dashboard_enable_ansi(void);   /* needed once on Windows consoles */
void dashboard_render(const DashboardConfig *cfg, const PriorityQueue *q,
                      const ResponseEngine *re);
/* Detailed card for a single processed request. */
void dashboard_show_response(const DashboardConfig *cfg,
                             const ResponseEngine *re, const Emergency *e);

#endif
