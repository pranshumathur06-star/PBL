#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "response.h"

/* ---------- name tables ---------- */
static const char *CAT_NAMES[CAT_COUNT] =
    { "Medical", "Fire", "Accident", "Crime", "Breakdown", "Unknown" };
static const char *RT_NAMES[RT_COUNT] =
    { "Ambulance", "Fire Truck", "Police", "Mechanic" };
static const char *ST_NAMES[] =
    { "QUEUED", "DISPATCHED", "NO RESPONDER", "REJECTED" };

const char *category_name(Category c)       { return CAT_NAMES[c]; }
const char *responder_type_name(ResponderType t) { return RT_NAMES[t]; }
const char *status_name(Status s)           { return ST_NAMES[s]; }

/* ---------- city graph ---------- */
enum { N_CLOCK, N_ISBT, N_RAJPUR, N_PREM, N_BYPASS, N_GEU,
       N_HOSPITAL, N_FIRE, N_POLICE, N_MECH, N_MUSS, N_RAIPUR, N_TOTAL };

static void add_edge(CityGraph *g, int a, int b, int km)
{
    g->w[a][b] = g->w[b][a] = km;
}

static void load_default_city(CityGraph *g)
{
    static const char *names[N_TOTAL] = {
        "Clock Tower", "ISBT", "Rajpur Road", "Premnagar", "Bypass",
        "Graphic Era", "Doon Hospital", "Fire Station", "Police HQ",
        "Mechanic Yard", "Mussoorie Rd", "Raipur"
    };
    memset(g, 0, sizeof *g);
    g->n = N_TOTAL;
    for (int i = 0; i < N_TOTAL; i++)
        snprintf(g->names[i], MAX_NAME, "%s", names[i]);

    add_edge(g, N_CLOCK,  N_ISBT,     3);
    add_edge(g, N_CLOCK,  N_RAJPUR,   2);
    add_edge(g, N_CLOCK,  N_POLICE,   2);
    add_edge(g, N_ISBT,   N_GEU,      4);
    add_edge(g, N_ISBT,   N_PREM,     6);
    add_edge(g, N_RAJPUR, N_MUSS,     5);
    add_edge(g, N_RAJPUR, N_HOSPITAL, 3);
    add_edge(g, N_PREM,   N_BYPASS,   5);
    add_edge(g, N_PREM,   N_GEU,      3);
    add_edge(g, N_GEU,    N_FIRE,     3);
    add_edge(g, N_GEU,    N_MECH,     2);
    add_edge(g, N_BYPASS, N_MECH,     4);
    add_edge(g, N_BYPASS, N_RAIPUR,   6);
    add_edge(g, N_HOSPITAL, N_POLICE, 2);
    add_edge(g, N_FIRE,   N_RAIPUR,   5);
    add_edge(g, N_MUSS,   N_RAIPUR,   8);
}

/* ---------- Dijkstra (O(V^2), fine for a city-sized graph) ---------- */
void response_dijkstra(const CityGraph *g, int src, int dist[], int prev[])
{
    int done[MAX_NODES] = {0};
    for (int i = 0; i < g->n; i++) { dist[i] = INF; prev[i] = -1; }
    dist[src] = 0;

    for (int iter = 0; iter < g->n; iter++) {
        int u = -1;
        for (int i = 0; i < g->n; i++)
            if (!done[i] && dist[i] < INF && (u < 0 || dist[i] < dist[u])) u = i;
        if (u < 0) break;
        done[u] = 1;
        for (int v = 0; v < g->n; v++)
            if (g->w[u][v] > 0 && dist[u] + g->w[u][v] < dist[v]) {
                dist[v] = dist[u] + g->w[u][v];
                prev[v] = u;
            }
    }
}

/* ---------- hash map: category -> helpline ---------- */
static unsigned hash_str(const char *s)
{
    unsigned h = 5381;
    while (*s) h = h * 33 + (unsigned char)*s++;
    return h % HASH_BUCKETS;
}

static void helpline_put(ResponseEngine *re, Category cat, ResponderType needs,
                         const char *service, const char *number)
{
    Helpline *h = calloc(1, sizeof *h);
    if (!h) return;
    snprintf(h->key, sizeof h->key, "%s", category_name(cat));
    h->cat = cat;
    h->needs = needs;
    snprintf(h->service, sizeof h->service, "%s", service);
    snprintf(h->number, sizeof h->number, "%s", number);
    unsigned b = hash_str(h->key);
    h->next = re->buckets[b];
    re->buckets[b] = h;
}

const Helpline *response_lookup_helpline(const ResponseEngine *re, Category c)
{
    const char *key = category_name(c);
    for (const Helpline *h = re->buckets[hash_str(key)]; h; h = h->next)
        if (strcmp(h->key, key) == 0) return h;
    return NULL;
}

/* ---------- responders ---------- */
static void add_responder(ResponseEngine *re, const char *name,
                          ResponderType type, int node)
{
    if (re->n_responders >= MAX_RESPONDERS) return;
    Responder *r = &re->responders[re->n_responders];
    r->id = re->n_responders + 1;
    snprintf(r->name, sizeof r->name, "%s", name);
    r->type = type;
    r->home_node = r->node = node;
    r->available = 1;
    r->missions = 0;
    re->n_responders++;
}

const Responder *response_find_responder(const ResponseEngine *re, int id)
{
    for (int i = 0; i < re->n_responders; i++)
        if (re->responders[i].id == id) return &re->responders[i];
    return NULL;
}

/* ---------- init / free ---------- */
void response_init(ResponseEngine *re)
{
    memset(re, 0, sizeof *re);
    load_default_city(&re->graph);

    add_responder(re, "AMB-01",  RT_AMBULANCE,  N_HOSPITAL);
    add_responder(re, "AMB-02",  RT_AMBULANCE,  N_ISBT);
    add_responder(re, "FIRE-01", RT_FIRE_TRUCK, N_FIRE);
    add_responder(re, "FIRE-02", RT_FIRE_TRUCK, N_MUSS);
    add_responder(re, "POL-01",  RT_POLICE,     N_POLICE);
    add_responder(re, "POL-02",  RT_POLICE,     N_BYPASS);
    add_responder(re, "MECH-01", RT_MECHANIC,   N_MECH);
    add_responder(re, "MECH-02", RT_MECHANIC,   N_RAIPUR);

    helpline_put(re, CAT_MEDICAL,   RT_AMBULANCE,  "Ambulance",      "108");
    helpline_put(re, CAT_FIRE,      RT_FIRE_TRUCK, "Fire Service",   "101");
    helpline_put(re, CAT_ACCIDENT,  RT_AMBULANCE,  "ERSS Emergency","112");
    helpline_put(re, CAT_CRIME,     RT_POLICE,     "Police",         "112");
    helpline_put(re, CAT_BREAKDOWN, RT_MECHANIC,   "Highway Helpline","1033");
}

void response_free(ResponseEngine *re)
{
    for (int i = 0; i < HASH_BUCKETS; i++) {
        Helpline *h = re->buckets[i];
        while (h) { Helpline *n = h->next; free(h); h = n; }
        re->buckets[i] = NULL;
    }
    LogNode *l = re->log_head;
    while (l) { LogNode *n = l->next; free(l); l = n; }
    re->log_head = NULL;
    re->log_count = 0;
}

/* ---------- log (linked list, newest at head) ---------- */
static void log_add(ResponseEngine *re, const Emergency *e)
{
    LogNode *n = malloc(sizeof *n);
    if (!n) return;
    n->record = *e;
    n->next = re->log_head;
    re->log_head = n;
    re->log_count++;
}

int response_log_recent(const ResponseEngine *re, Emergency *out, int max)
{
    int n = 0;
    for (const LogNode *l = re->log_head; l && n < max; l = l->next)
        out[n++] = l->record;
    return n;
}

/* ---------- dispatch ---------- */
Status response_dispatch(ResponseEngine *re, Emergency *e)
{
    re->total++;
    e->responder_id = -1;
    e->route_len = 0;
    e->distance_km = 0;
    e->eta_min = 0;

    /* 1. verification: fake / unclear / invalid location is never dispatched */
    if (!e->genuine || e->confidence < CONF_THRESHOLD ||
        e->category == CAT_UNKNOWN ||
        e->location < 0 || e->location >= re->graph.n) {
        e->status = ST_REJECTED;
        re->rejected++;
        log_add(re, e);
        return e->status;
    }

    /* 2. which service handles this category? (hash map lookup) */
    const Helpline *h = response_lookup_helpline(re, e->category);
    if (!h) {
        e->status = ST_NO_RESPONDER;
        re->unserved++;
        log_add(re, e);
        return e->status;
    }

    /* 3. shortest distances from the emergency to every node */
    int dist[MAX_NODES], prev[MAX_NODES];
    response_dijkstra(&re->graph, e->location, dist, prev);

    /* 4. nearest AVAILABLE responder of the needed type */
    int best = -1;
    for (int i = 0; i < re->n_responders; i++) {
        const Responder *r = &re->responders[i];
        if (!r->available || r->type != h->needs || dist[r->node] >= INF) continue;
        if (best < 0 || dist[r->node] < dist[re->responders[best].node]) best = i;
    }

    if (best < 0) {
        e->status = ST_NO_RESPONDER;
        re->unserved++;
        log_add(re, e);
        return e->status;
    }

    /* 5. assign: following prev[] from the responder leads to the emergency */
    Responder *r = &re->responders[best];
    e->responder_id = r->id;
    e->distance_km  = dist[r->node];
    e->eta_min      = e->distance_km * MIN_PER_KM;
    if (e->eta_min < 1) e->eta_min = 1;
    for (int cur = r->node; cur != -1 && e->route_len < MAX_NODES; cur = prev[cur])
        e->route[e->route_len++] = cur;

    r->available = 0;
    r->node = e->location;
    r->missions++;

    e->status = ST_DISPATCHED;
    re->dispatched++;
    re->eta_sum += e->eta_min;
    log_add(re, e);
    return e->status;
}

int response_release(ResponseEngine *re, int responder_id)
{
    for (int i = 0; i < re->n_responders; i++) {
        Responder *r = &re->responders[i];
        if (r->id == responder_id && !r->available) {
            r->available = 1;
            r->node = r->home_node;
            return 1;
        }
    }
    return 0;
}
