#include <stdio.h>
#include <string.h>
#include <time.h>
#include "dashboard.h"

#ifdef _WIN32
#include <windows.h>
void dashboard_enable_ansi(void)
{
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode;
    if (GetConsoleMode(h, &mode)) SetConsoleMode(h, mode | 0x0004);
}
#else
void dashboard_enable_ansi(void) {}
#endif

#define WIDTH 86
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"
#define DIM     "\033[2m"

static const char *clr(const DashboardConfig *c, const char *code)
{
    return c->use_color ? code : "";
}

static const char *status_color(Status s)
{
    switch (s) {
        case ST_DISPATCHED:   return GREEN;
        case ST_REJECTED:     return RED;
        case ST_NO_RESPONDER: return YELLOW;
        default:              return CYAN;
    }
}

static void line(char ch)
{
    for (int i = 0; i < WIDTH; i++) putchar(ch);
    putchar('\n');
}

static void section(const DashboardConfig *c, const char *title)
{
    printf("\n%s%s%s\n", clr(c, BOLD), title, clr(c, RESET));
    line('-');
}

static void sev_bar(char *buf, int sev)
{
    for (int i = 0; i < 10; i++) buf[i] = (i < sev) ? '#' : '.';
    buf[10] = '\0';
}

static void route_string(const ResponseEngine *re, const Emergency *e,
                         char *buf, size_t n)
{
    buf[0] = '\0';
    for (int i = 0; i < e->route_len; i++) {
        size_t used = strlen(buf);
        snprintf(buf + used, n - used, "%s%s", i ? " > " : "",
                 re->graph.names[e->route[i]]);
    }
}

static const char *loc_name(const ResponseEngine *re, int node)
{
    return (node >= 0 && node < re->graph.n) ? re->graph.names[node] : "?";
}

/* ---------- sections ---------- */
static void print_banner(const DashboardConfig *c)
{
    char ts[32];
    time_t now = time(NULL);
    strftime(ts, sizeof ts, "%d %b %Y  %H:%M:%S", localtime(&now));
    line('=');
    printf("%s EASE - Emergency Assistance & Smart Response Engine      LIVE DASHBOARD%s\n",
           clr(c, BOLD), clr(c, RESET));
    printf(" %s\n", ts);
    line('=');
}

static void print_summary(const DashboardConfig *c, const PriorityQueue *q,
                          const ResponseEngine *re)
{
    int free_units = 0;
    for (int i = 0; i < re->n_responders; i++) free_units += re->responders[i].available;
    double avg = re->dispatched ? (double)re->eta_sum / re->dispatched : 0.0;

    printf(" Received: %-4d Queued: %s%-3d%s Dispatched: %s%-3d%s Rejected: %s%-3d%s "
           "Unserved: %s%-3d%s\n",
           re->total + q->size,
           clr(c, CYAN),   q->size,        clr(c, RESET),
           clr(c, GREEN),  re->dispatched, clr(c, RESET),
           clr(c, RED),    re->rejected,   clr(c, RESET),
           clr(c, YELLOW), re->unserved,   clr(c, RESET));
    printf(" Responders free: %d/%d    Average ETA: %.1f min\n",
           free_units, re->n_responders, avg);
}

static void print_queue(const DashboardConfig *c, const PriorityQueue *q,
                        const ResponseEngine *re)
{
    Emergency top[5];
    int n = pq_snapshot(q, top, 5);

    section(c, "PRIORITY QUEUE  (next to be dispatched)");
    if (n == 0) { printf(" (queue empty)\n"); return; }
    printf(" %-2s %-4s %-12s %-10s %-5s %-13s %s\n",
           "#", "ID", "Severity", "Category", "Conf", "Location", "Message");
    for (int i = 0; i < n; i++) {
        char bar[11];
        sev_bar(bar, top[i].severity);
        printf(" %-2d %-4d %s%s%s %-2d %-10s %3.0f%%  %-13.13s %.28s\n",
               i + 1, top[i].id,
               clr(c, top[i].severity >= 8 ? RED : top[i].severity >= 5 ? YELLOW : GREEN),
               bar, clr(c, RESET), top[i].severity,
               category_name(top[i].category), top[i].confidence * 100,
               loc_name(re, top[i].location), top[i].message);
    }
    if (q->size > n) printf(" ... and %d more waiting\n", q->size - n);
}

static void print_classification(const DashboardConfig *c, const ResponseEngine *re)
{
    Emergency rec[5];
    int n = response_log_recent(re, rec, 5);

    section(c, "CLASSIFICATION RESULTS  (most recent first)");
    if (n == 0) { printf(" (nothing processed yet)\n"); return; }
    printf(" %-4s %-10s %-10s %-6s %s\n", "ID", "Category", "Genuine", "Conf", "Message");
    for (int i = 0; i < n; i++)
        printf(" %-4d %-10s %s%-10s%s %3.0f%%   %.40s\n",
               rec[i].id, category_name(rec[i].category),
               clr(c, rec[i].genuine ? GREEN : RED),
               rec[i].genuine ? "YES" : "NO", clr(c, RESET),
               rec[i].confidence * 100, rec[i].message);
}

static void print_outcomes(const DashboardConfig *c, const ResponseEngine *re)
{
    Emergency rec[5];
    int n = response_log_recent(re, rec, 5);

    section(c, "DISPATCH OUTCOMES  (most recent first)");
    if (n == 0) { printf(" (nothing processed yet)\n"); return; }
    printf(" %-4s %-13s %-9s %-14s %-7s %s\n",
           "ID", "Status", "Unit", "Incident at", "Dist", "ETA");
    for (int i = 0; i < n; i++) {
        const Responder *r = response_find_responder(re, rec[i].responder_id);
        char dist[12] = "-", eta[12] = "-";
        if (rec[i].status == ST_DISPATCHED) {
            snprintf(dist, sizeof dist, "%d km", rec[i].distance_km);
            snprintf(eta, sizeof eta, "%d min", rec[i].eta_min);
        }
        printf(" %-4d %s%-13s%s %-9s %-14.14s %-7s %s\n",
               rec[i].id, clr(c, status_color(rec[i].status)),
               status_name(rec[i].status), clr(c, RESET),
               r ? r->name : "-", loc_name(re, rec[i].location), dist, eta);
    }
}

static void print_fleet(const DashboardConfig *c, const ResponseEngine *re)
{
    section(c, "RESPONDER FLEET");
    for (int i = 0; i < re->n_responders; i++) {
        const Responder *r = &re->responders[i];
        printf(" %-8s %-11s at %-14s %s%-10s%s missions: %d\n",
               r->name, responder_type_name(r->type), loc_name(re, r->node),
               clr(c, r->available ? GREEN : YELLOW),
               r->available ? "AVAILABLE" : "ON MISSION", clr(c, RESET),
               r->missions);
    }
}

static void print_helplines(const DashboardConfig *c, const ResponseEngine *re)
{
    section(c, "HELPLINE DIRECTORY");
    for (int cat = 0; cat < CAT_UNKNOWN; cat++) {
        const Helpline *h = response_lookup_helpline(re, (Category)cat);
        if (h)
            printf(" %-10s -> %-18s %s\n", h->key, h->service, h->number);
    }
}

/* ---------- public API ---------- */
void dashboard_render(const DashboardConfig *cfg, const PriorityQueue *q,
                      const ResponseEngine *re)
{
    if (cfg->clear_screen) printf("\033[H\033[J");
    print_banner(cfg);
    print_summary(cfg, q, re);
    print_queue(cfg, q, re);
    print_classification(cfg, re);
    print_outcomes(cfg, re);
    print_fleet(cfg, re);
    print_helplines(cfg, re);
    putchar('\n');
    fflush(stdout);
}

void dashboard_show_response(const DashboardConfig *cfg,
                             const ResponseEngine *re, const Emergency *e)
{
    const Responder *r = response_find_responder(re, e->responder_id);
    const Helpline  *h = response_lookup_helpline(re, e->category);
    char route[200];

    printf("\n%s+-- RESPONSE FOR REQUEST #%d %s\n", clr(cfg, BOLD), e->id, clr(cfg, RESET));
    printf(" | Message   : %s\n", e->message);
    printf(" | Location  : %s\n", loc_name(re, e->location));
    printf(" | Category  : %s  (confidence %.0f%%, %s)\n",
           category_name(e->category), e->confidence * 100,
           e->genuine ? "genuine" : "flagged as fake/unclear");
    printf(" | Severity  : %d/10\n", e->severity);
    printf(" | Status    : %s%s%s\n", clr(cfg, status_color(e->status)),
           status_name(e->status), clr(cfg, RESET));

    switch (e->status) {
    case ST_DISPATCHED:
        route_string(re, e, route, sizeof route);
        printf(" | Responder : %s (%s)\n", r ? r->name : "?",
               r ? responder_type_name(r->type) : "?");
        printf(" | Route     : %s\n", route);
        printf(" | Distance  : %d km     ETA: %d min\n", e->distance_km, e->eta_min);
        if (h) printf(" | Helpline  : %s (%s)\n", h->number, h->service);
        break;
    case ST_NO_RESPONDER:
        printf(" | Action    : all %s units are busy.",
               h ? responder_type_name(h->needs) : "matching");
        if (h) printf(" Call %s (%s) now.", h->number, h->service);
        printf("\n");
        break;
    case ST_REJECTED:
        printf(" | Action    : not dispatched - request failed verification.\n");
        break;
    default:
        break;
    }
    printf("+%s\n", "-----------------------------------------------");
    fflush(stdout);
}
