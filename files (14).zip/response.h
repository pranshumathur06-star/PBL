/* response.h - Response module: verify -> look up helpline -> find nearest
 * available responder (Dijkstra) -> assign -> log.
 *
 * Data structures used:
 *   graph (adjacency matrix) + Dijkstra  : nearest-responder routing
 *   hash map (chaining)                  : category -> helpline / service
 *   singly linked list                   : request history log
 */
#ifndef RESPONSE_H
#define RESPONSE_H

#include "ease.h"

#define HASH_BUCKETS 11

typedef struct {
    int  n;
    char names[MAX_NODES][MAX_NAME];
    int  w[MAX_NODES][MAX_NODES];      /* edge length in km, 0 = no road */
} CityGraph;

typedef struct {
    int           id;
    char          name[MAX_NAME];
    ResponderType type;
    int           home_node;
    int           node;                /* current position               */
    int           available;
    int           missions;
} Responder;

typedef struct Helpline {
    char            key[MAX_NAME];     /* category name, the hash key    */
    Category        cat;
    ResponderType   needs;             /* responder type that handles it */
    char            service[MAX_NAME];
    char            number[16];
    struct Helpline *next;
} Helpline;

typedef struct LogNode {
    Emergency       record;
    struct LogNode *next;
} LogNode;

typedef struct {
    CityGraph  graph;
    Responder  responders[MAX_RESPONDERS];
    int        n_responders;
    Helpline  *buckets[HASH_BUCKETS];
    LogNode   *log_head;               /* newest first                   */
    int        log_count;
    /* statistics for the dashboard */
    int        total, dispatched, rejected, unserved;
    long       eta_sum;
} ResponseEngine;

void  response_init(ResponseEngine *re);
void  response_free(ResponseEngine *re);

/* Dijkstra from src: fills dist[] and prev[] (prev[src] = -1). */
void  response_dijkstra(const CityGraph *g, int src, int dist[], int prev[]);

const Helpline  *response_lookup_helpline(const ResponseEngine *re, Category c);
const Responder *response_find_responder(const ResponseEngine *re, int id);

/* Main entry point. Updates *e (status, responder, route, ETA), updates
 * statistics and appends to the log. Returns the final status. */
Status response_dispatch(ResponseEngine *re, Emergency *e);

/* Mark a responder free again (back at base). 1 ok, 0 not found/not busy. */
int   response_release(ResponseEngine *re, int responder_id);

/* Copies up to `max` most recent log records, newest first. */
int   response_log_recent(const ResponseEngine *re, Emergency *out, int max);

#endif
